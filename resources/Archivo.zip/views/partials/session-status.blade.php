@if (session('status'))

	<div 
		class="alert alert-success alert-dismissible fade show" 
		role="alert">
		{{ session('status') }}
		<button
			class="close"
			type="button"
			data-dismiss="alert"
			arial-label="Close"
			autofocus
			>
			<span arial-hidden="true">&times;</span>
		</button>
	</div>
	
@endif