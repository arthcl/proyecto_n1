©{{ date('Y') }} {{ config('app.name') }} | Todos los derechos reservados.
