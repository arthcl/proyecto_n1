<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>

 @include('partials.header')

</head>

<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
	<!-- ///////////////////////////////////  CONTENIDO DE LA CABECERA PANEL - INICIO   ///////////////////// -->


	<!-- Navbar -->
	<nav class="main-header navbar navbar-expand navbar-white navbar-light">
	<!-- Left navbar links -->
	<ul class="navbar-nav">
		<li class="nav-item">
		<a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
		</li>
		<li class="nav-item d-none d-sm-inline-block">
		<a href="{{ route('home') }}" class="nav-link">Inicio</a>
		</li>
		<li class="nav-item d-none d-sm-inline-block">
		<a href="{{ route('panel') }}" class="nav-link">Panel</a>
		</li>
		<!-- <li class="nav-item d-none d-sm-inline-block">
		<a href="#" class="nav-link">Contacto</a>
		</li> -->
	</ul>
		<form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
			@csrf
		</form>
		<!-- SEARCH FORM -->
		<!-- Right navbar links -->
	 
		<ul class="navbar-nav ml-auto">
							 
				<li class="nav-item">
					<button class="btn btn-primary {{setActive('logout')}}" 
					href="#" 
					onclick="event.preventDefault();
						document.getElementById('logout-form').submit();">
						<i class="fas fa-sign-out-alt px-1"></i>
						@lang('Logout')
					</button>
				</li>
		</ul>
	
	</nav>
	<!-- ///////////////////////  CONTENIDO DEL SIDEBAR PRINCIPAL   ///////////////////// -->

	<!-- Main Sidebar Container -->
	<aside class="main-sidebar sidebar-light-primary elevation-3">
		<!-- Brand Logo -->
		<a href="{{ route('home') }}" class="brand-link">
			<img src="{{asset('dist/img/emg.jpg')}}" alt="EMG Logo" class="brand-image img-circle elevation-2"
					 style="opacity: .8; width: 300; height: 300">
			<span class="brand-text font-weight-light">{{ config('app.name') }}</span>
		</a>

		<!-- Sidebar -->
		<div class="sidebar">
			<!-- Sidebar user panel (optional) -->
			<div class="user-panel mt-3 pb-3 mb-3 d-flex">
				<div class="image">
					<img
						style="width: 160; height: 160"
						src="{{asset('dist/img/male_avatar.svg')}}" 
						class="img-circle elevation-2" 
						alt="User Image">
				</div>
				<div class="info">
						@auth
							{{ auth()->user()->nombre }}
						@endauth 
				</div>
			</div>

		 <!-- Sidebar Menu -->
		<nav class="mt-2">
		<ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
			<!-- Add icons to the links using the .nav-icon class
				 with font-awesome or any other icon font library -->
				<?php
				
				// SE OBTIENE EL PATH ACTUAL
				$path_completo = Request::path();
				// SE SEPARA SI TIENE / , Y SE COMPARA CON EL INDICE 0 DEL ARRAY
				$path_actual = explode( '/', $path_completo );

				// SE OBTIENE EL ID DEL TIPO USUARIO
				$id = Auth::user()->tipo_usuario_id ;

				switch ($id) {
					case 1:
						?>
						<!-- ADMINISTRADOR -->
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('panel')}}" class="nav-link <?=($path_actual[0] == 'panel')?"active":"";?> ">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('orden_trabajo.index')}}" class="nav-link <?=($path_actual[0] == 'orden_trabajo')?"active":"";?>">
								<i class="nav-icon fas fa-wrench"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Orden de Trabajo</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('servicio.index')}}" class="nav-link <?=($path_actual[0] == 'servicio')?"active":"";?>">
								<i class="nav-icon fas fa-cogs"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Servicios</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('usuario.index')}}" class="nav-link <?=($path_actual[0] == 'usuario')?"active":"";?>">
								<i class="nav-icon fas fa-users"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Usuarios</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('vehiculo.index')}}" class="nav-link <?=($path_actual[0] == 'vehiculo')?"active":"";?>">
								<i class="nav-icon fas fa-car-side"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Vehículos</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('taller.index')}}" class="nav-link <?=($path_actual[0] == 'taller')?"active":"";?>">
								<i class="nav-icon fas fa-warehouse"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Taller</p>
							</a>
						</li>
						<?php
						break;

					case 2:
						?>
						<!-- SUPERVISOR -->
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('panel')}}" class="nav-link <?=($path_actual[0] == 'panel')?"active":"";?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('orden_trabajo.index')}}" class="nav-link <?=($path_actual[0] == 'orden_trabajo')?"active":"";?>">
								<i class="nav-icon fas fa-wrench"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Orden de Trabajo</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('servicio.index')}}" class="nav-link <?=($path_actual[0] == 'servicio')?"active":"";?>">
								<i class="nav-icon fas fa-cogs"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Servicios</p>
							</a>
						</li>
						<?php
						break;

					case 3:
						?>
						<!-- MECANICO -->
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('panel')}}" class="nav-link <?=($path_actual[0] == 'panel')?"active":"";?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Dashboard</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('orden_trabajo.index')}}" class="nav-link <?=($path_actual[0] == 'orden_trabajo')?"active":"";?>">
								<i class="nav-icon fas fa-wrench"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Orden de Trabajo</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('servicio.index')}}" class="nav-link <?=($path_actual[0] == 'servicio')?"active":"";?>">
								<i class="nav-icon fas fa-cogs"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Servicios</p>
							</a>
						</li>
						<?php
						break;

					case 4:
						?>
						<!-- CLIENTE -->
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('panel')}}" class="nav-link <?=($path_actual[0] == 'panel')?"active":"";?>">
								<i class="nav-icon fas fa-tachometer-alt"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Inicio</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('servicio.index')}}" class="nav-link <?=($path_actual[0] == 'servicio')?"active":"";?>">
								<i class="nav-icon fas fa-cogs"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Servicios</p>
							</a>
						</li>
						<li class="nav-item">
							<!-- <a href="pages/widgets.html" class="nav-link"> -->
							<a href="{{route('vehiculo.index')}}" class="nav-link <?=($path_actual[0] == 'vehiculo')?"active":"";?>">
								<i class="nav-icon fas fa-car-side"></i>
								<!-- <i class="right fas fa-angle-left"></i> -->
								<p>Vehículos</p>
							</a>
						</li>
						<?php
						break;
					
					default:
						echo "default";
						break;
				}
				?>
			
	   
				<!-- <li class="nav-item has-treeview menu-open">
					<a href="#" class="nav-link ">
						<i class="nav-icon fas fa-tachometer-alt"></i>
						<p>Dashboard <i class="right fas fa-angle-left"></i></p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="{{route('administrador.index')}}" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Administrador</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('supervisor.index') }}" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Supervisor</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('cliente.index') }}" class="nav-link ">
								<i class="far fa-circle nav-icon"></i>
								<p>Cliente</p>
							</a>
						</li>
					</ul>
				</li>
					

				<li class="nav-item has-treeview menu-open">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-tachometer-alt"></i>
						<p>Vistas CRUD<i class="right fas fa-angle-left"></i></p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="{{ route('usuario.index')}}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Vista Usuario</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('vehiculo.index') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Vista Vehículo</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('taller.index') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Vista Taller</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('servicio.index') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Vista Servicio</p>
							</a>
						</li>
					</ul>
				</li>


				<li class="nav-item has-treeview menu-open">
					<a href="#" class="nav-link">
						<i class="nav-icon fas fa-edit"></i>
						<p>Formularios <i class="right fas fa-angle-left"></i></p>
					</a>
					<ul class="nav nav-treeview">
						<li class="nav-item">
							<a href="{{ route('usuario.create') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Usuario</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('vehiculo.create')}}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Vehículo</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('taller.create') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Taller</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('servicio.create') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Servicio</p>
							</a>
						</li>
						<li class="nav-item">
							<a href="{{ route('orden_trabajo.create') }}" class="nav-link">
								<i class="far fa-circle nav-icon"></i>
								<p>Órden de trabajo</p>
							</a>
						</li>
					</ul>
				</li> -->


							 
			<!-- <li class="nav-item has-treeview menu-open">
				<a href="#" class="nav-link active">
					<i class="nav-icon fas fa-tachometer-alt"></i>
					<p>Dashboard <i class="right fas fa-angle-left"></i></p>
				</a>
				<ul class="nav nav-treeview">
					<li class="nav-item">
						<a href="{{route('administrador.index')}}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Administrador</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('supervisor.index') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Supervisor</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('cliente.index') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Cliente</p>
						</a>
					</li>
				</ul>
			</li>
				

			<li class="nav-item has-treeview menu-open">
				<a href="#" class="nav-link active">
					<i class="nav-icon fas fa-tachometer-alt"></i>
					<p>Vistas CRUD<i class="right fas fa-angle-left"></i></p>
				</a>
				<ul class="nav nav-treeview">
					<li class="nav-item">
						<a href="{{ route('usuario.index')}}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Vista Usuario</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('vehiculo.index') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Vista Vehículo</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('taller.index') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Vista Taller</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('servicio.index') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Vista Servicio</p>
						</a>
					</li>
				</ul>
			</li>


			<li class="nav-item has-treeview menu-open">
				<a href="#" class="nav-link active">
					<i class="nav-icon fas fa-edit"></i>
					<p>Formularios <i class="right fas fa-angle-left"></i></p>
				</a>
				<ul class="nav nav-treeview">
					<li class="nav-item">
						<a href="{{ route('usuario.create') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Usuario</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('vehiculo.create')}}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Vehículo</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('taller.create') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Taller</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('servicio.create') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Servicio</p>
						</a>
					</li>
					<li class="nav-item">
						<a href="{{ route('orden_trabajo.create') }}" class="nav-link active">
							<i class="far fa-circle nav-icon"></i>
							<p>Órden de trabajo</p>
						</a>
					</li>
				</ul>
			</li> -->
		</ul>
		</nav>
		<!-- /.sidebar-menu -->
	</div>
	<!-- /.sidebar -->
	</aside>

	<!-- ///////////////////////////////////  CONTENIDO INTERNO   /////////////////////////////// -->

	<!-- Content Wrapper. Contains page content -->
	<div class="content-wrapper">
		<!-- CONTENIDO DE LA CABECERA -->
		@yield('content_header')

		<!-- CONTENIDO PRINCIPAL -->
		<section class="content">
			<div class="container-fluid">
				<!-- SE INCLUYE EL COMPONENTE DE INDICADORES  -->
				@yield('content_boxes')
				<!-------------------------------------------------------------- -->
				<!-- Main row -->
				<div class="row ml-auto">
					<!-- Left col -->
					@yield('content')
				</div>
			</div><!-- /.container-fluid -->
		</section>
	</div>

<!-- SE INCLUYE EL CONTENIDO DEL FOOTER PRINCIPAL EN EL DASHBOARD -->
	<footer class="main-footer text-center">
		@include('partials.footer')
	</footer>

	<!-- Control Sidebar -->
	<aside class="control-sidebar control-sidebar-dark">
		<!-- Control sidebar content goes here -->
	</aside>
	<!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- SCRIPTS UNICOS  -->
<!-- <script src="{{asset('plugins/jquery/jquery.min.js')}}"></script> -->
<!-- <script src="{{asset('plugins/jquery-ui/jquery-ui.min.js')}}"></script> -->


<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
	$.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="{{asset('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{asset('plugins/chart.js/Chart.min.js')}}"></script>

<!-- jQuery Knob Chart -->
<script src="{{asset('plugins/jquery-knob/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{asset('plugins/moment/moment.min.js')}}"></script>
<script src="{{asset('plugins/daterangepicker/daterangepicker.js')}}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')}}"></script>
<!-- Summernote -->
<script src="{{asset('plugins/summernote/summernote-bs4.min.js')}}"></script>
<!-- overlayScrollbars -->
<script src="{{asset('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{asset('dist/js/adminlte.js')}}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<!-- <script src="dist/js/pages/dashboard.js"></script> -->
<!-- AdminLTE for demo purposes -->
<!-- <script src="dist/js/demo.js"></script> -->


<!-- CLONADOR JQUERY -->
<script src="{{ asset('js/clonar_orden_trabajo.js') }}" ></script>



</body>
</html>
