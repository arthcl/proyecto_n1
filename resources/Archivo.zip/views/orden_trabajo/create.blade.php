@extends('layouts.dashboard')


@section('title','ORDEN_TRABAJO')
<!--------------------------------->
@section('content_header')
<div class="content-header">
	<div class="container-fluid">
		<div class="row mb-2">
			<div class="col-lg-12 text-center col-sm-6">
				<h1 class="m-0 text-dark ">Crear nueva órden de trabajo</h1>
				<hr>
			</div><!-- /.col -->
		</div><!-- /.row -->
	</div><!-- /.container-fluid -->
</div>
@endsection
<!--------------------------------->

@section('content')
<div class="container">
	<div class="row">
		<div class="col-12 col-lg-10 mx-auto mb-5">
			
			@include('errors.formErrors')
			
			<form class="bg-white shadow rounded py-3 px-4" method="POST" action="{{ route('register') }}">
				
				@csrf

				<!---Tipo Orden de Trabajo -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Tipo OT (*)
						</span>
					</div>
					<select class="form-control text-dark" id="tipo_ot" name="tipo_ot" autocomplete="tipo_ot">
						<option value="0">Seleccionar...</option>
						<option value="1">Mantención - 10.000KM</option>
						<option value="2">Mantención - 20.000KM</option>
						<option value="3">Mantención - 30.000KM</option>
						<option value="4">Mantención - 40.000KM</option>
					</select>
				</div>
					
				
				<!---Fecha de Ingreso -->	
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Fecha ingreso (*)
						</span>
					</div>
					<input class="form-control" placeholder="Ingrese fecha de ingreso taller" type="date" name="fecha_ingreso" value="{{old('fecha_ingreso')}}">
				</div>


				<!-- MANTENCION -->
				<br>
				<label for="">Mantención</label>
				<hr>

				<!---KM Actual -->	
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Kilometraje Actual (*)
						</span>
					</div>
					<input placeholder="Ingrese kilometraje actual del vehículo" id="km_actual" type="number" class="form-control" name="km_actual" value="{{ old('km_actual') }}" max="10" autocomplete="km_actual">
				</div>


				<!--- PROXIMA MANTENCION KILOMETRAJE -->	
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Próx. Mant. KM (*)
						</span>
					</div>
					<input placeholder="Ingrese próximo kilometraje de mantención" id="km_proximo" type="number" class="form-control" name="km_proximo" value="{{ old('km_proximo') }}" max="10" autocomplete="km_proximo">
				</div>

				<!--- FECHA PROXIMA MANTENCION KILOMETRAJE -->	
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Fecha Prox. Mant. (*)
						</span>
					</div>
					<input class="form-control" placeholder="Ingrese fecha de próxima mantención" type="date" name="fecha_proxima_mantencion" value="{{old('fecha_proxima_mantencion')}}">
				</div>

				<!-- MANTENCION -->
				<br>
				<label for="">Reparación</label>
				<hr>

				<!--- PROXIMA MANTENCION KILOMETRAJE -->	
				<!-- <div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Próx. Mant. KM (*)
						</span>
					</div>
					<input placeholder="Ingrese próximo kilometraje de mantención" id="km_proximo" type="number" class="form-control" name="km_proximo" value="{{ old('km_proximo') }}" max="10" autocomplete="km_proximo">
				</div> -->


				<!-- MANTENCION -->
				<br>
				<label for="">Pintura</label>
				<hr>

				<!-- Campo COLOR ORIGINAL -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Color Original: (*)
						</span>
					</div>
					<input placeholder="Ingrese color original del vehículo" id="color_original" type="text" class="form-control" name="color_original" value="{{ old('color_original') }}" max="10" autocomplete="color_original">
				</div>

				<!-- Campo COLOR APLICAR  -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Color Aplicar: (*)
						</span>
					</div>
					<input placeholder="Ingrese color aplicar al vehículo" id="color_aplicar" type="text" class="form-control" name="color_aplicar" value="{{ old('color_aplicar') }}" max="10" autocomplete="color_aplicar">
				</div>

				<hr class="mt-5 py-3">

				<!-- Campo NUMERO COTIZACION  -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Número Cotización: (*)
						</span>
					</div>
					<input placeholder="Ingrese número de cotización" id="numero_cotizacion" type="number" class="form-control" name="numero_cotizacion" value="{{ old('numero_cotizacion') }}" max="10" autocomplete="numero_cotizacion">
				</div>


				<!-- Campo oc si existe  -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Orden de Compra: (*)
						</span>
					</div>
					<input placeholder="Ingrese órden de compra" id="orden_compra" type="number" class="form-control" name="orden_compra" value="{{ old('orden_compra') }}" max="10" autocomplete="numero_cotizacion">
				</div>

				<hr>

				<h3 class="my-2 py-4 h5">1.- Descripción problema y/o requerimiento</h3>
				<!-- Campo comentario -->
				<!---Observacion Servicio -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Descripción OT: (*)
						</span>
					</div>
					<textarea class="form-control text-dark" name="descripcion_ot" id="descripcion_ot" cols="30" rows="3" placeholder="Ingrese descripción de OT"></textarea>
				</div>


				<h3 class="my-2 py-4 h5">2.- Descripción trabajos realizados</h3>
				<!-- Campo comentario -->
				<div class="form-group row">
					<div class="cloned-row-descripcion">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="item_descripcion_trabajos_realizados">Item</label>
									<input type="text" class="form-control" id="item_descripcion_trabajos_realizados_1" name="item_descripcion_trabajos_realizados[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="unidad_descripcion_trabajos_realizados">Unidad</label>
									<select name="unidad_descripcion_trabajos_realizados" id="unidad_descripcion_trabajos_realizados" class="form-control">
										<option value="0">Seleccione...</option>
										<option value="1">Litros</option>
										<option value="1">Unidad</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="cantidad_descripcion_trabajos_realizados">Cantidad</label>
									<input type="number" class="form-control id="cantidad_descripcion_trabajos_realizados" name="cantidad_descripcion_trabajos_realizados[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="valor_descripcion_trabajos_realizados">Valor</label>
									<input type="number" class="form-control" id="valor_descripcion_trabajos_realizados" name="valor_descripcion_trabajos_realizados[]" />
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 text-right">
						<button type="button" class="form-control btn btn-success col-sm-1" value="clonar_descipcion_trabajo_realizado" id="clonar_descipcion_trabajo_realizado">
								<i class="fas fa-plus"></i>
							</button>
						<button type="button" class="form-control btn btn-danger col-sm-1" value="eliminar_descipcion_trabajo_realizado" id="eliminar_descipcion_trabajo_realizado">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>


				<h3 class="my-2 py-4 h5">3.- Repuestos</h3>
				<!-- Campo comentario -->
				<div class="form-group row">
					<div class="cloned-row-repuestos">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="item_repuestos">Item</label>
									<input type="text" class="form-control" id="item_repuestos" name="item_repuestos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="unidad_repuestos">Unidad</label>
									<select name="unidad_repuestos" id="unidad_repuestos" class="form-control">
										<option value="0">Seleccione...</option>
										<option value="1">Litros</option>
										<option value="1">Unidad</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="cantidad_repuestos">Cantidad</label>
									<input type="number" class="form-control" id="cantidad_repuesto" name="cantidad_repuestos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="valor_repuestos">Valor</label>
									<input type="number" class="form-control" id="valor_repuestos" name="valor_repuestos[]" />
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 text-right">
						<button type="button" class="form-control btn btn-success col-sm-1" value="clonar_repuestos" id="clonar_repuestos">
								<i class="fas fa-plus"></i>
							</button>
						<button type="button" class="form-control btn btn-danger col-sm-1" value="eliminar_repuestos" id="eliminar_repuestos">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>



				<h3 class="my-2 py-4 h5">4.- Insumos</h3>
				<!-- Campo comentario -->
				<div class="form-group row">
					<div class="cloned-row-insumos">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="item_insumos">Item</label>
									<input type="text" class="form-control" id="item_insumos" name="item_insumos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="unidad_insumos">Unidad</label>
									<select name="unidad_insumos" id="unidad_insumos" class="form-control">
										<option value="0">Seleccione...</option>
										<option value="1">Litros</option>
										<option value="1">Unidad</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="cantidad_insumos">Cantidad</label>
									<input type="number" class="form-control" id="cantidad_insumos" name="cantidad_insumos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="valor_insumos">Valor</label>
									<input type="number" class="form-control" id="valor_insumos" name="valor_insumos[]" />
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 text-right">
						<button type="button" class="form-control btn btn-success col-sm-1" value="clonar_insumos" id="clonar_insumos">
								<i class="fas fa-plus"></i>
							</button>
						<button type="button" class="form-control btn btn-danger col-sm-1" value="eliminar_insumos" id="eliminar_insumos">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>


				<h3 class="my-2 py-4 h5">5.- Fluidos</h3>
				<!-- Campo comentario -->
				<div class="form-group row">
					<div class="cloned-row-fluidos">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="item_fluidos">Item</label>
									<input type="text" class="form-control" id="item_fluidos" name="item_fluidos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="unidad_fluidos">Unidad</label>
									<!-- <input type="text" class="form-control name="unidad_fluidos[]" /> -->
									<select name="unidad_fluidos" id="unidad_fluidos" class="form-control">
										<option value="0">Seleccione...</option>
										<option value="1">Litros</option>
										<option value="1">Unidad</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="cantidad_fluidos">Cantidad</label>
									<input type="number" class="form-control" id="cantidad_fluidos" name="cantidad_fluidos[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="valor_fluidos">Valor</label>
									<input type="number" class="form-control" id="valor_fluidos" name="valor_fluidos[]" />
								</div>
							</div>
						</div>
					</div>

					<div class="col-12 text-right">
						<button type="button" class="form-control btn btn-success col-sm-1" value="clonar_fluidos" id="clonar_fluidos">
								<i class="fas fa-plus"></i>
							</button>
						<button type="button" class="form-control btn btn-danger col-sm-1" value="eliminar_fluidos" id="eliminar_fluidos">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>



				<h3 class="my-2 py-4 h5">6.- Servicios Extras</h3>
				<!-- Campo comentario -->
				<div class="form-group row">
					<div class="cloned-row-servicios">
						<div class="row">
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="item_servicios_extra">Item</label>
									<input type="text" class="form-control" id="item_servicios_extra" name="item_servicios_extra[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="unidad_servicios_extra">Unidad</label>
									<select name="unidad_servicios_extra" id="unidad_servicios_extra" class="form-control">
										<option value="0">Seleccione...</option>
										<option value="1">Litros</option>
										<option value="1">Unidad</option>
									</select>
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="cantidad_servicios_extra">Cantidad</label>
									<input type="number" class="form-control" id="cantidad_servicios_extra" name="cantidad_servicios_extra[]" />
								</div>
							</div>
							<div class="col-md-3">
								<div class="form-group">
									<label class="control-label" for="valor_servicios_extra">Valor</label>
									<input type="number" class="form-control" id="valor_servicios_extra" name="valor_servicios_extra[]" />
								</div>
							</div>
						</div>
					</div>
					<div class="col-12 text-right">
						<button type="button" class="form-control btn btn-success col-sm-1" value="clonar_servicios" id="clonar_servicios">
								<i class="fas fa-plus"></i>
							</button>
						<button type="button" class="form-control btn btn-danger col-sm-1" value="eliminar_servicios" id="eliminar_servicios">
							<i class="fas fa-minus"></i>
						</button>
					</div>
				</div>

				<h3 class="my-2 py-4 h5">7.- Comentarios</h3>
				<!-- Campo comentario -->
				<div class="input-group mb-3">
					<div class="input-group-prepend w-25">
						<span class="input-group-text w-100">
							Comentarios:
						</span>
					</div>
					<textarea class="form-control text-dark" name="comentario_ot" id="comentario_ot" cols="30" rows="3" placeholder="Ingrese comentario de OT"></textarea>
				</div>

				<div class="col-12 text-center">
					<button class="btn btn-primary btn-lg mx-auto col-lg-4 offset-lg-4 ml-4 my-3" type="submit">
						<i class="far fa-save px-2"></i>
						Ingresar
					</button>
				</div>

			</form>		
		</div>
	</div>
</div>


@endsection


