@extends('layouts.dashboard')


@section('title','orden_trabajo')
<!--------------------------------->
@section('content_header')
  <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-12 col-sm-6 text-center">
            <h1 class="m-0 text-dark">Órden de Trabajo</h>
            <hr>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
@endsection
<!--------------------------------->
@section('content')
<section class="col-lg-12 mx-auto">
    
	<div class="col-12 text-right">
		<a class="btn btn-primary" href="{{route('orden_trabajo.create')}}" title=""><i class="fa fa-plus" aria-hidden="true"></i>
			Agregar Orden de Trabajo
		</a>
	</div>

	<div class="col-12 mt-3 table-responsive">
		<h2 class="h4 text-dark">Activos</h2>
		<table class="table table-hover bg-light shadow-sm table-sm table-responsive-sm text-center">
			<thead class="thead-dark">
				<tr>
				<th scope="col">#</th>
				<th scope="col">Cliente</th>
				<th scope="col">Vehículo</th>
				<th scope="col">Patente</th>
				<th scope="col">Fecha inicio</th>
				<th scope="col">Tipo Servicio</th>
				<th scope="col">Tipo OT</th>
				<th scope="col">Número Cotización</th>
				<th scope="col">Órden de Compra</th>
				<th scope="col">Descripción OT</th>
				<th scope="col">Taller</th>
				<th scope="col">Acción</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<th scope="row">1</th>
					<td>Juan Pérez</td>
					<td>Suzuki Alto</td>
					<td>DK-FK-33</td>
					<td>24-12-2020</td>
					<td>Mantención</td>
					<td>Mantención 10.000</td>
					<td>567958</td>
					<td>3101</td>
					<td>Se realiza mantención programada.</td>
					<td>CARS</td>
					<td>
						<a class="btn btn-info btn-sm d-flex" href="" title="">
							<i class="fa fa-eye px-2 my-auto" aria-hidden="true"></i>
							Ver
						</a>
					</td>
				</tr>
			</tbody>
		</table>
	</div>

</section>

<!---------------------------------------------------------------->
@endsection