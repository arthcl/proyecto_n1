@extends('layouts.dashboard')

@section('title', $vehiculo->user->name)

@section('title','VEHICULO')
<!--------------------------------->
@section('content_header')
	<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-12 text-center col-sm-6">
            <h1 class="m-0 text-dark ">Detalles del vehiculo</h1>
            @include('errors.formErrors')
            @include('partials.session-status') 
            <hr>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
@endsection


@section('content')
<section class="col-lg-12 text-center mb-3 ">
  <div class="container">
    <div class="row">
      <div class="col-6">
        <div class="card">
          <div class="card-header bg-warning">
            <h4>{{ $vehiculo->patente }}</h4>
          </div>
            <div class="table-responsive  border">
              
              <div class="card-body">
                <table class="table col-12">
                  <tbody class="text-left">
                    <tr>
                      <td class="py-0 font-weight-bold">Cliente: {{ $vehiculo->user->name}} {{$vehiculo->user->last_name}}</td>

                    
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">Modelo:</span> {{ $vehiculo->modelo }}</td>
                    </tr>
                    <tr>
                     <td class="py-0"><span class="font-weight-bold">Indicador KM/hr:</span> Esta se ingresara manualmente </td>
                    </tr>
                    <tr >
                      <td class="py-0"><span class="font-weight-bold mb-0">Revisión Tec : </span> {{ date('d-m-Y', strtotime($vehiculo->revision_tecnica)) }}</td>
                    </tr>
                  
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">horometro:</span> {{ $vehiculo->horometro }}</td>
                    
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">extintor:</span> {{ $vehiculo->extintor }}</td>
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">permiso de circulacion:</span> {{ $vehiculo->permiso_circulacion }}</td>
                      
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">año:</span> {{ $vehiculo->año }}</td>
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">nomenclatura neumatico:</span> {{ $vehiculo->nomenclatura_neumatico }}</td>
                      
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">tipo de vehiculo:</span> {{ $vehiculo->tipo_vehiculos->nombre}}</td>
                      
                    </tr>
                    <tr>
                      <td class="py-0"><span class="font-weight-bold">tipo de motor:</span> {{ $vehiculo->tipo_motor->nombre}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div class="card-footer">
                <small class="text-black-50 p-3">
                  Registrado 
                  {{  $vehiculo->created_at->diffForHumans() ?? '-'  }}
                </small>
              </div>
              <div class="d-flex justify-content-center align-items-center py-2">
                <a class="btn btn-outline-primary" 
                  href="{{ route('usuario.show', $vehiculo->user )}}" 
                  title="">

                  <i class="fas fa-undo"></i>
                  volver
                </a>

                <a 
                  class="btn btn-primary btn-group-sm"
                  href="{{ route('vehiculo.edit', $vehiculo->id) }}" 
                  title="">
                  <i class="fas fa-user-edit"></i>
                </a>
                <a 
                  class="btn btn-danger"
                  href="#"
                  onclick="document.getElementById('delete-vehiculo').submit()" 
                  title="">
                  <i class="fas fa-trash"></i>   
                </a>
              
                <form 
                  class="d-none" 
                  id="delete-vehiculo" 
                  action="{{ route('vehiculo.destroy', $vehiculo->id) }}" 
                  method="POST" 
                  accept-charset="utf-8">
                  @csrf
                  @method('DELETE')
                </form>
              </div>
            
          </div>           
        </div>
      </div>
      <div class="col-6">
        <div class="card">
          <div class="card-header bg-primary">
            Asignar Servicio
          </div>
          <form action="{{ route('servicio_vehiculo.store') }}" method="POST">
            @csrf

            <input type="hidden" name="vehiculo_id" value="{{ $vehiculo->id }}">
            <div class="card-body">
              <div class="input-group mb-3">
              
                  <div class="input-group-prepend">
                    <label class="input-group-text" for="inputGroupSelect01">Servicio</label>
                  </div>
                  <select class="custom-select" name="servicio_id">
                    <option value="">Seleccionar...</option>
                    @forelse($servicios as $serv)
                    <option value="{{$serv->id}}">{{$serv->nombre}}
                    @empty
                    <h3>no hay servicios disponibles aún</h3>
                    @endforelse                 
                  </select>
              </div>
              <button class="btn btn-outline-primary" type="">Enviar</button>
            </div>
          </form>
          <div class="card-footer">
            <a class="text-success" >
              Actualmente en {{$servicio_vehiculo->nombre ?? 'sin asignar'}}
            </a>
          </div>
        </div>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">Servicio</th>
              <th scope="col">Fecha</th>
              <th scope="col">Ver Actividades</th>
            </tr>
          </thead>
          <tbody>
            @forelse( $vehiculo->servicios as $servicio_veh)
              <tr>
                <th scope="row">{{ $servicio_veh->nombre}}</th>
                <td>{{ $servicio_veh->created_at }}</td>
                <td>
                  <a class="btn btn-outline-primary" 
                    href="{{ route('actividad.index') }}" 
                    title="">

                    <i class="fas fa-eye"></i>
                  </a>
                </td>
              </tr>
              @empty
                <small class="text-danger">esté vehiculo aun no se asigna a un servicio</small>            
            @endforelse
            
          </tbody>
        </table>
      </div>
    </div>  
  </div> 


             
        
@endsection