<section class="col-lg-12 connectedSortable mx-auto">
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center mb-3">

                <h3 class="mb-0">Listado</h3>
          
            </div>
                <hr>              
                    <table class="table table-hover bg-light shadow-sm table-sm table-responsive-sm text-center">
                        <thead class="thead-dark">
                            <tr>
                              
                              <th scope="col">Patente</th>
                              <th scope="col">Modelo</th>
                              <th scope="col">Año</th>
                              <th scope="col">Ingreso</th>
                              <th scope="col">Servicio</th>
                              <th scope="col">Actividad</th>
                              <th scope="col">Estado</th>
                              <th scope="col">ver</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                            
                                <tr class="shadow-sm">
                                  <th scope="row" class="font-weight-bold">patente</th>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td class="text-center"><a href="" title=""><i class="fas fa-eye"></i></a></td>
                                 
                                </tr>
                            
                        </tbody>
                    </table>
                    <ul>    
                        {{-- $usuario->links() --}}
                    </ul>
            </div>  
        </div> 
    </section>