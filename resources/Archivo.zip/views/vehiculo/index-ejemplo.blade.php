@extends('layouts.dashboard')


@section('title','ASIGNAR-VEHICULOS')
<!--------------------------------->
@section('content_header')
	<div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-lg-12 text-center col-sm-6">
            <h1 class="m-0 text-dark ">Vehiculos</h1>
            <hr>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
@endsection


@section('content')
      <section class="col-lg-12 connectedSortable mx-auto">
        <div class="row">
            <div class="col-lg-12">
                <div class="d-flex justify-content-between align-items-center mb-3">

                <h3 class="mb-0">Listado</h3>
          
            </div>
                <hr>              
                    <table class="table table-hover bg-light shadow-sm table-sm table-responsive-sm text-center">
                        <thead class="thead-dark">
                            <tr>
                              <th scope="col">Cliente</th>
                              <th scope="col">Patente</th>
                              <th scope="col">Modelo</th>
                              <th scope="col">Año</th>
                              <th scope="col">Ingreso</th>
                              <th scope="col">Servicio</th>
                              <th scope="col">Actividad</th>
                              <th scope="col">Estado</th>
                             
                            </tr>
                        </thead>
                        <tbody>
                            
                                <tr class="shadow-sm">
                                  <th scope="row" class="font-weight-bold">nombre del cliente</th>
                                  <td>patente</td>
                                  <td>modello</td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                                  <td class="text-center"><a href="" title=""><i class="fas fa-eye"></i></a></td>
                                 
                                </tr>
                            @empty
                                <p class="lead text-secondary">No existen registros aún</p>
                            @endforelse
                        </tbody>
                    </table>
                    <ul>    
                        {{-- $usuario->links() --}}
                    </ul>
            </div>  
        </div> 
    </section>
@endsection