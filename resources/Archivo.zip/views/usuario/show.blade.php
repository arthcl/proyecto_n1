@extends('layouts.dashboard')


@section('title','PANEL -' . $usuario->nombre)
<!--------------------------------->
@section('content_header')
	<div class="content-header">
			<div class="container-fluid">
				<div class="row mb-2">
					<div class="col-lg-12 text-center col-sm-6">
						<h1 class="m-0 text-dark ">{{ $usuario->nombre }}</h1>
						<hr>
					</div><!-- /.col -->
				</div><!-- /.row -->
			</div><!-- /.container-fluid -->
		</div>
@endsection

<!--------------------------------->


@section('content')
<!-- <section class="col-lg-6 text-center mb-3 "> -->

	<div class="container">
		<div class="row">
			<div class="col-12 col-lg-12 mx-auto mb-5">

		
			
				<div class="row">

					<div class="col-md-4 mb-3">
						<label for="tipo_usuario">Tipo usuario</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="tipo_usuario">
									@
								</span>
							</div>
							<input value="{{ $usuario->tipo_usuario->descripcion }}" type="text" class="form-control" id="tipo_usuario" placeholder="Tipo de usuario" aria-describedby="tipo_usuario" >
						</div>
					</div>

					<div class="col-md-4 mb-3">
						<label for="tipo_cliente">Tipo cliente</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="tipo_cliente">
									@
								</span>
							</div>
							<input value="{{ $usuario->tipo_cliente->descripcion }}" type="text" class="form-control" id="tipo_cliente" placeholder="Tipo de cliente" aria-describedby="tipo_cliente" >
						</div>
					</div>

					<div class="col-md-4 mb-3">
						<label for="taller_usuario">Taller</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="taller_usuario">
									@
								</span>
							</div>
							<input value="{{ $usuario->tipo_taller_id }}" type="text" class="form-control" id="taller_usuario" placeholder="Taller" aria-describedby="taller_usuario" >
						</div>
					</div>

				</div>
				
				<hr class="my-4 text-dark">

				<div class="row">

					<div class="col-md-4 mb-3">
						<label for="nombres">Nombres</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="nombres">
									@
								</span>
							</div>
							<input value="{{ $usuario->nombre }}" type="text" class="form-control" id="nombres" placeholder="Tipo de usuario" aria-describedby="nombres" >
						</div>
					</div>

					<div class="col-md-4 mb-3">
						<label for="tipo_cliente">Tipo cliente</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="tipo_cliente">
									@
								</span>
							</div>
							<input value="{{ $usuario->tipo_cliente->descripcion }}" type="text" class="form-control" id="tipo_cliente" placeholder="Tipo de cliente" aria-describedby="tipo_cliente" >
						</div>
					</div>

					<div class="col-md-4 mb-3">
						<label for="taller_usuario">Taller</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text" id="taller_usuario">
									@
								</span>
							</div>
							<input value="{{ $usuario->tipo_taller_id }}" type="text" class="form-control" id="taller_usuario" placeholder="Taller" aria-describedby="taller_usuario" >
						</div>
					</div>
					<!---NOMBRES -->
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Nombres
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ $usuario->nombre }}
							</label>	
						</div>
					</div>
				
					<!---RUT -->
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Rut
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ $usuario->rut }}
							</label>	
						</div>
					</div>

					<!---Paterno -->
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Paterno
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ $usuario->a_paterno }}
							</label>	
						</div>
					</div>

					<!---Materno -->
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Materno
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ $usuario->a_materno }}
							</label>	
						</div>
					</div>

					<!---Genero -->	                	
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Género
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ $usuario->genero->descripcion ?? '--' }}
							</label>	
						</div>
					</div>
					
					<!-- FECHA NACIMIENTO-->
					<div class="col-lg-6">
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Fecha nacimiento
								</span>
							</div>
							<label class="font-weight-normal form-control" id="t_asociado">
								{{ date('d-m-Y', strtotime($usuario->f_nacimiento)) }}
							</label>
						</div>
					</div>



					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>
					<div class="col-lg-6"></div>

				</div>
					
					<!-- TIPO CLIENTE PARTICULAR -->
					<div id="cliente_particular">
						

						

						
		
						

						<hr class="my-4 text-dark">

					</div>

					

					<!-- TIPO CLIENTE EMPRESA -->
					<div id="cliente_empresa">

						<!---RUT -->
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Rut
								</span>
							</div>
							<input placeholder="Ingrese RUT" id="rut" type="text" class="form-control" name="rut" value="{{ old('rut') }}" autocomplete="rut" autofocus> 
						</div>

						<!---NOMBRES -->
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Razón Social
								</span>
							</div>
							<input placeholder="Ingrese razón social" id="razon_social" type="text" class="form-control" name="nombre" value="{{ old('nombre') }}" autocomplete="razon social"> 
						</div>

						<!---NOMBRE -->
						<div class="input-group mb-3">
							<div class="input-group-prepend w-25">
								<span class="input-group-text w-100">
									Nombre
								</span>
							</div>
							<input placeholder="Ingrese nombre de empresa" id="nombre" type="text" class="form-control" name="nombre" value="{{ old('nombre') }}" autocomplete="nombre"> 
						</div>
								
						<hr class="my-4 text-dark">

					</div>
																			
					


					<!---DIRECCIÓN -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<span class="input-group-text w-100">
								Dirección
							</span>
						</div>
						<input placeholder="Ingrese dirección" class="form-control" id="direccion" type="text" name="direccion" value="{{ old('direccion') }}" autocomplete="direccion">
					</div>
					
					<!---NUMERO DIRECCION -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<span class="input-group-text w-100">
								Nº
							</span>
						</div>
						<input placeholder="Ingrese número dirección" class="form-control" id="numeracion" type="number" name="numeracion" value="{{ old('numeracion') }}" autocomplete="numeracion">
					</div>
					
					<!--- Region -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<label class="input-group-text w-100" for="select_region">
								Region
							</label>
						</div>
						<input type="text" id="region">						
					</div>
					
					<!---Provincia -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<label 
								for="select_provincia" 
								class="input-group-text w-100"> {{ __('Provincia')}}
							</label>
						</div>
						<input type="text" id="select_provincia"> 	
					</div>
					
					<!---Comuna -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<label 
								for="select_comuna" 
								class="input-group-text w-100"> {{ __('Comuna')}}
							</label>
						</div>
							<select 
							class="custom-select" 
							id="select_comuna"
							name="select_comuna">
								
								<option selected>Seleccionar...</option>
								
							</select>  	
					</div>
					<!---TELEFONO PARTICULAR -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<span class="input-group-text w-100">
								Celular
							</span>
						</div>
						<input placeholder="Ingrese celular" class="form-control" id="telefono_1" type="tel" name="telefono 1" value="{{ old('telefono_1') }}" autocomplete="telefono_1">
					</div>
					
					<!---TELEFONO FIJO -->
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<span class="input-group-text w-100">
								Teléfono fijo
							</span>
						</div>
						<input placeholder="Ingrese teléfono fijo" class="form-control" id="telefono_2" type="tel" name="telefono_2" value="{{ old('telefono_2') }}" autocomplete="telefono_2">
					</div>		                		                
					
					<!---EMAIL -->	
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<span class="input-group-text w-100">
								Correo
							</span>
						</div>
						<input placeholder="Ingrese correo electrónico" id="email" type="email" class="form-control" name="email" value="{{ old('email') }}"  autocomplete="email">
					</div>
					
					<!---PASSWORD -->	
					<div class="input-group mb-3">
						<div class="input-group-prepend w-25">
							<button class="btn btn-primary w-100" type="button" id="btnGenerarPass">
								Generar Contraseña
							</button>
						</div>
						<input placeholder="Haga click en el botón Generar Contraseña " value="{{old('password') }}" id="password" name="password" type="text" class="form-control h-auto">
					</div>
					
					<!---BOTONES DE OPCIONES -->			                
					<div class="input-group d-flex justify-content-center">
						<!-- <a class="btn btn-outline-secondary" href="{{ route('usuario.index') }}" title="">
							Volver
						</a> -->
						<button class="btn btn-primary btn-lg col-lg-4 offset-lg-4 ml-4 my-3" type="submit">
							<i class="far fa-save px-2"></i>
							Ingresar
						</button>
					</div>

				</form>		
			</div>
		</div>
	</div>

	<div class="container">
		<div class="table-responsive table-borderless border py-2">
			<h4>{{ $usuario->nombre }} {{ $usuario->last_name }}</h4>
			<table class="table">

			<tbody class="text-left">
				<tr>
					<td><span class="font-weight-bold">Rut:</span> {{ $usuario->rut }}</td>
					<td><span class="font-weight-bold">Correo:</span> {{ $usuario->email }}</td>
				</tr>
				<tr>
					<td><span class="font-weight-bold">Dirección:</span> {{ $usuario->direccion }}</td>
					<td><span class="font-weight-bold">Nº:</span> {{ $usuario->numeracion }}</td>
				</tr>
				<tr>
					<td><span class="font-weight-bold">Edad:</span> {{ $usuario->edad }}</td>
					<td><span class="font-weight-bold">Genero:</span> {{ $usuario->generos->nombre ?? '-' }}</td>
				</tr>
				<tr>
					<td><span class="font-weight-bold">Telefono:</span> {{ $usuario->telefono_1 }}</td>
					<td><span class="font-weight-bold">Telefono fijo:</span> {{ $usuario->telefono_2 }}</td>
				</tr>
				<tr>
					<td><span class="font-weight-bold">Tipo de cliente:</span> {{ $usuario->tipo_clientes->nombre  ?? '-'}}</td>
					<td><span class="font-weight-bold">Comuna:</span> {{ $usuario->comunas->nombre  ?? '-' }}</td>
				</tr>
			</tbody>
			</table>
		</div>
		
		<div>
			<p class="text-black-50 p-3">
				{{  $usuario->created_at->diffForHumans() ?? '-'  }}
			</p>
		</div>
			

			<div class="d-flex justify-content-center align-items-center">
				<a class="btn btn-outline-primary" 
					href="{{ route('usuario.index') }}" 
					title="">
					<i class="fas fa-undo"></i>
				</a>

						<a 
							class="btn btn-primary btn-group-sm"
							href="{{ route('usuario.edit', $usuario) }}" 
							title="">
							<i class="fas fa-user-edit"></i>
						</a>
						<a 
							class="btn btn-danger"
							href="#"
							onclick="document.getElementById('delete-usuario').submit()" 
							title="">
							<i class="fas fa-trash"></i>   
						</a>
				 
					
					<form 
						class="d-none" 
						id="delete-usuario" 
						action="{{ route('usuario.destroy', $usuario) }}" 
						method="POST" 
						accept-charset="utf-8">
						@csrf
						@method('DELETE')
					</form>
			</div>

	</div>


</section>

<!-------------- PANEL  VEHICULOS 
<section class="col-lg-12 text-center connectedSortable mx-auto mb-5">
<div class="container">
	<div class="card">
		<div class="card-header">
			<ul class="nav nav-pills" id="pills-tab" role="tablist">
				<li class="nav-item" role="presentation">
					<a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">Ingresar Vehiculo</a>
				</li>
				<li class="nav-item" role="presentation">
					<a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Sus Vehiculos</a>
				</li>
				<li class="nav-item" role="presentation">
					<a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Contact</a>
				</li>
			</ul>
		</div>
	
		<div class="card-body">
			<div class="tab-content" id="pills-tabContent">
				<div class="tab-pane fade show active  " id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
				</div>
				<div class="tab-pane fade " id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
		
				</div>
				<div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
					Contact
				</div>
			</div>
		</div>

	</div>
</div>
	
--------------------------------->
<!-- </section> -->

@endsection